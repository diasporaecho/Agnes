"""Regenerate the browser data from the checked research snapshots. No network calls."""
import json,re,html
from pathlib import Path
ROOT=Path(__file__).resolve().parent
documents=[json.loads(p.read_text()) for p in sorted((ROOT/'research').glob('research_*.json'))]
source_map={}; raw_countries=[]
for doc in documents:
    ss=doc.get('sources',[])
    if isinstance(ss,dict):ss=[dict(v,id=k) for k,v in ss.items()]
    for s in ss:source_map[s['id']]=s
    for c in doc['countries']:
        for s in c.get('sources',[]):source_map[s['id']]=s
        raw_countries.append(c)
shared=[
('shared-irs','IRS: Americans living abroad','https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad'),
('shared-ssa','SSA: work outside the United States','https://www.ssa.gov/benefits/retirement/planner/international.html'),
('shared-fbar','FinCEN: foreign account reporting','https://www.fincen.gov/report-foreign-bank-and-financial-accounts'),
('shared-fx','ECB: currency reference rates, November 6, 2026','https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html'),
('shared-recruit','Search Associates: candidate requirements and contracts','https://www.searchassociates.com/Candidates/FAQs.aspx'),
('shared-advisory','U.S. Department of State: current travel advisories','https://travel.state.gov/en/international-travel/travel-advisories.html'),
('shared-pages','GitHub: configuring Pages publication','https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site'),
]
for k,t,u in shared:source_map[k]={'id':k,'title':t,'url':u}
# This source failed a direct retrieval. Keep a working official index and the explicit
# uncertainty in the text, rather than presenting a known broken link as verified.
if 'pa-friendly' in source_map:
    source_map['pa-friendly']['url']=source_map['pa-decrees']['url']
    source_map['pa-friendly']['title']='Panama: current decree index (Friendly Nations PDF could not be verified)'
sources=[]
for i,(k,s) in enumerate(source_map.items(),1):
    s['number']=i
    sources.append({'id':k,'number':i,'title':re.sub(r'([A-Za-z])(?=20[0-9]{2})',r'\1 ',s['title']),'url':s['url'],'checked':'2026-11-08','country':{'gr':'Greece','it':'Italy','es':'Spain','pt':'Portugal','mx':'Mexico','pa':'Panama','th':'Thailand','ae':'United Arab Emirates UAE'}.get(re.split('[-_]',k)[0],'General')})

def text(v):
    v=str(v)
    # Repair spacing in compact research notes, without changing numeric amounts.
    v=re.sub(r'([A-Za-z])(?=20(?:2[0-9]))',r'\1 ',v)
    v=re.sub(r'(November|October|September|August|July|Level|step|Step|age|after|across|under|about|of)(?=\d)',r'\1 ',v)
    v=re.sub(r'(\d)(?=(?:months|years|year|days|month|million|sqm|days|hours)\b)',r'\1 ',v)
    v=v.replace("Teacher Horizons'2026","Teacher Horizons’ 2026").replace('US$ &','US$ &')
    return html.escape(v)

def refs(keys):
    if not keys:return ''
    if isinstance(keys,str):keys=[keys]
    result=[]
    for k in dict.fromkeys(keys):
        if k not in source_map:raise ValueError(f'Unresolved source: {k}')
        s=source_map[k]
        result.append(f'<a href="{html.escape(s["url"],quote=True)}" target="_blank" rel="noopener" title="{html.escape(s["title"],quote=True)}">[{s["number"]}]</a>')
    return '<p class="source-links">Sources: '+''.join(result)+'</p>'

labels={'text':'','publishedEvidence':'Published compensation','benefits':'Benefits','taxCaution':'Tax treatment','otherSchoolTypes':'Other teaching roles','savings':'Offer-testing example','independentIncome':'Independent income','longTerm':'Long-term residence','work':'School-sponsored work','citizenship':'Citizenship','permanent':'Permanent residence','status':'Evidence status','evidence':'What is published','scenario':'Illustrative offer test','negotiation':'What to request','marketContext':'Recruiter market context','evidenceType':'Evidence type','buying':'Buying a home','residencyLink':'Ownership and residence','examples':'Examples','example':'Housing asking-price examples','portals':'Property search','conflict':'Conflicting guidance','notes':'Practical notes'}
omit={'sources','source','benefitSources','marketSources','ref','checked'}
def render(v):
    if isinstance(v,str):return f'<p>{text(v)}</p>'
    if isinstance(v,list):
        if all(isinstance(x,str) for x in v):
            return '<ul>'+''.join('<li>'+text(x)+'</li>' for x in v)+'</ul>'
        return ''.join(render(x) for x in v)
    if isinstance(v,dict):
        out=''
        if 'route' in v:out+=f'<h5 class="school-title">{text(v["route"])}</h5>'
        for k,x in v.items():
            if k in omit or k=='route':continue
            if k=='portals':
                out+='<p class="small">Search: '
                for p in x:
                    u=p if isinstance(p,str) else p['url'];n=u.split('/')[2] if isinstance(p,str) else p['name']
                    out+=f'<a href="{html.escape(u,quote=True)}" target="_blank" rel="noopener">{text(n)} ↗</a> · '
                out+='</p>';continue
            if isinstance(x,(dict,list)):out+=render(x);continue
            label=labels.get(k,re.sub(r'(?<!^)(?=[A-Z])',' ',k).replace('_',' ').capitalize())
            out+='<p>'+ (f'<span class="field-label">{text(label)}.</span> ' if label else '')+text(x)+'</p>'
            if k=='benefits':out+=refs(v.get('benefitSources',[]))
            if k=='marketContext':out+=refs(v.get('marketSources',[]))
        out+=refs(v.get('sources',v.get('source',[])))
        return out
    return ''

def cities(cs):
    out=''
    for c in cs:
        out+=f'<article class="city"><h5>{text(c["name"])}</h5>'
        for k,v in c.items():
            if k in ['name','sources']:continue
            label={'areas':'Neighborhoods to investigate','neighborhoods':'Neighborhoods to investigate','assessment':'Everyday fit','tradeoff':'Everyday fit','dailyLife':'Everyday fit','fit':'Everyday fit','tradeoffs':'Tradeoffs','housingExample':'Asking-price snapshot','rentEvidence':'Asking-price snapshot','housingEstimate':'Planning estimate','rentUSDPlanning':'Monthly rent planning range (USD)'}.get(k,k)
            val=f'${v[0]:,}–${v[1]:,}; planning allowance, not a market average.' if isinstance(v,list) and len(v)==2 else v
            out+=f'<p><span class="field-label">{text(label)}.</span> {text(val)}</p>'
        out+=refs(c.get('sources',[]))+'</article>'
    return out

def schools(ss):
    out=''
    for s in ss:
        out+=f'<article class="school"><p class="school-title"><a href="{html.escape(s["url"],quote=True)}" target="_blank" rel="noopener">{text(s.get("name",s.get("school")))} ↗</a></p>'
        for k in ['location','fit','status','notes','examples']:
            if k in s:out+=f'<p><span class="field-label">{text(k.capitalize())}.</span> {text(s[k])}</p>'
        if 'vacanciesURL' in s:out+=f'<p><a href="{html.escape(s["vacanciesURL"],quote=True)}" target="_blank" rel="noopener">School vacancy portal ↗</a></p>'
        out+=refs(s.get('sources',s.get('source',[])))+'</article>'
    return out

meta={
'greece':dict(code='GR',tagline='A specific route for qualified teachers.',teach=3,independent=5,city='Athens / Chalandri',opportunity='U.S.-curriculum school sponsorship',gate='A matching opening and complete benefit terms',reason='ACS publishes a clear U.S.-hire pathway and benefits. Confirm the actual opening and compensation basis before building a move around it.',livingReason='A workable independent-income route if the current means test is met; Greek language and permit conditions shape the long-term plan.',roles=[],currency='EUR',rate=1/1.1165,totals=[1800,2450,3450],rent=950,setup=3200,salary='ACS Athens publishes €25,000–33,000 package bands (about $27,913–36,845); annual basis and gross/net treatment need confirmation.'),
'italy':dict(code='IT',tagline='Culture-rich living. A selective job market.',teach=8,independent=4,city='Turin / Chieri',opportunity='Qualifying foreign-school teacher route',gate='School sponsorship and realistic net pay',reason='A special foreign-school route exists, but the reviewed vacancies do not establish a current sponsored fit. Secure the right offer before moving.',livingReason='Elective residence can suit substantial nonemployment income, with no teaching rights. A lower-cost city can improve the budget.',roles=[],currency='EUR',rate=1/1.1165,totals=[2050,2800,3900],rent=1250,setup=3800,salary='Historical Turin ad: €2,630–3,097 gross/month (about $2,936–3,458). Expired, EU-passport-only; not a current U.S.-applicant offer.'),
'thailand':dict(code='TH',tagline='The strongest first search for a classroom move.',teach=1,independent=6,city='Bangkok / school corridor',opportunity='Established international-school employers',gate='Licensing, package quality and exact subject fit',reason='Verified international-school postings, established employer pathways and manageable planning costs make Bangkok a sensible first search. Long-term status is less straightforward.',livingReason='Strong everyday affordability, but age-dependent nonworking retirement routes and more complex permanent-status pathways limit a general recommendation.',roles=['primary','secondary','support'],currency='THB',rate=33.503,totals=[1500,2200,3200],rent=700,setup=3000,salary='Recruiter context: $12,000–55,000 annual entry-level range across unequal school tiers. Written school pay and net deductions remain essential.'),
'uae':dict(code='AE',tagline='Strong packages, with a current security decision.',teach=6,independent=8,city='Abu Dhabi / Dubai',opportunity='Published pay and housing-inclusive packages',gate='Current Level 3 advisory; school eligibility',reason='Potentially strongest package-led savings, but the current regional-security advisory places it behind lower-risk first searches. ACS requires at least four years of experience.',livingReason='Higher self-funded housing costs and conditional long residence routes; no ordinary automatic permanent-residence or citizenship pathway.',roles=['primary','secondary','support'],currency='AED',rate=3.67,totals=[2400,3400,4800],rent=1650,setup=4200,salary='ACS Abu Dhabi BA/BS step 4: $44,177 / AED162,129 annual base. Four-year minimum; bonuses and gratuity are separate.',notice='Current safety check: U.S. advisory Level 3 — Reconsider Travel, October 23, 2026. Recheck regional conditions, insurance and departure options before accepting or traveling.'),
'spain':dict(code='ES',tagline='A strong lifestyle option once the route is settled.',teach=5,independent=1,city='Valencia / Puçol',opportunity='American and IB school leads',gate='Sponsorship, experience thresholds and net pay',reason='Appealing cities and school leads, but reviewed roles do not yet confirm an overseas opening and some schools require three to five years.',livingReason='A clear nonworking route and separate long-term residence pathway, subject to sufficient income and no paid work. Valencia offers a practical starting comparison.',roles=[],currency='EUR',rate=1/1.1165,totals=[1900,2550,3650],rent=1100,setup=3400,salary='No verified public numeric scale for the named schools. NALCAP stipends are assistant support, not qualified-teacher salaries.'),
'portugal':dict(code='PT',tagline='A European base with school-first housing decisions.',teach=4,independent=2,city='Porto / Matosinhos',opportunity='CAISL 2027–28 subject and support roles',gate='Rent-to-net-pay ratio and nationality-rule changes',reason='CAISL has relevant posted roles and a two-year minimum, but Lisbon-region rents and undisclosed pay require a written offer before the financial fit is known.',livingReason='Own-income and permanent-residence routes merit comparison. New U.S.-scenario nationality applicants must plan against the 2026 ten-year rule.',roles=['secondary','support'],currency='EUR',rate=1/1.1165,totals=[1800,2400,3500],rent=1100,setup=3300,salary='No verified public numeric scale for the named schools. Compare annual net income and housing costs rather than assumed monthly pay.'),
'mexico':dict(code='MX',tagline='A practical school-led move closer to home.',teach=2,independent=3,city='Mexico City / Querétaro',opportunity='American-curriculum international schools',gate='Written net package and consular/work approval',reason='U.S.-curriculum schools and employer-sponsored entry make a practical search. Actual vacancies and overseas-hire benefits still need confirmation; neighborhood choice matters.',livingReason='A four-year temporary-to-permanent route can be useful, but solvency thresholds may be much higher than living costs and vary by consulate.',roles=[],currency='MXN',rate=18.6297,totals=[1650,2200,3200],rent=850,setup=2700,salary='No verified current numeric scale for shortlisted schools. Benefits differ by hire category; request annual gross and net figures.'),
'panama':dict(code='PA',tagline='A smaller school market with useful long-term options.',teach=7,independent=7,city='Panama City / school corridor',opportunity='ISP secondary and learning-support postings',gate='Employer-specific work status and package details',reason='Verified ISP roles and international-hire benefits are useful leads, but a smaller researched employer pool and permit specificity reduce flexibility.',livingReason='Can move into the top three if a qualifying lifetime pension is confirmed. Without age or pension facts, the Pensionado route cannot be assumed.',roles=['secondary','support'],currency='USD',rate=1,totals=[1750,2400,3400],rent=1100,setup=2800,salary='ISP publishes overseas-hire benefits but no numeric salary scale. Confirm housing, retirement and flight eligibility in the contract.'),
}
categories=['Rent / housing','Utilities, internet & mobile','Groceries','Dining out','Transport','Insurance & health allowance','Visa / legal renewal reserve','Leisure','Trips home reserve']
comfort={
'greece':[950,230,350,200,150,170,50,170,180],
'italy':[1250,230,350,200,160,180,50,180,200],
'thailand':[700,160,280,200,200,200,60,200,200],
'uae':[1650,250,350,200,280,200,50,200,220],
'spain':[1100,190,320,200,130,170,50,190,200],
'portugal':[1100,180,300,160,130,160,50,150,170],
'mexico':[850,170,300,150,180,160,40,150,200],
'panama':[1100,190,320,150,200,160,50,100,130]}
countries=[]
for c in raw_countries:
    name=c.get('name',c.get('country'));slug=c.get('id',name.lower());m=meta[slug]
    sections=[]
    def add(title,body):sections.append({'title':title,'html':body})
    add('Teaching routes & qualifications',render(c['teaching']))
    add('School leads & vacancy status',schools(c.get('schools',c.get('jobs',[]))))
    compensation=c.get('compensation',c.get('salary',c.get('pay',{})))
    # Keep salary-source summaries concise across repeated uses.
    if slug=='greece':compensation={k:v for k,v in compensation.items() if k!='taxCaution'}
    add('Pay, benefits & contract questions',render(compensation))
    add('Cities & neighborhoods',cities(c['cities']))
    add('Visas, work & legal residence',render(c['immigration']))
    if 'settlement' in c:add('Permanent residence & citizenship',render(c['settlement']))
    add('Renting & buying',render(c.get('housing',c.get('property',{}))))
    health=c.get('healthTaxSafety',c.get('health_tax',c.get('healthTax')))
    add('Healthcare, taxes & everyday safety',render(health)+refs(c.get('healthTaxSources',[])))
    limits=c.get('uncertainties',c.get('verificationLimits'))
    if limits:add('What still needs a personal check',render(limits))
    rows=[];base=comfort[slug]
    assert sum(base)==m['totals'][1],(slug,sum(base))
    for total in m['totals']:
        vals=[round(x*total/sum(base)/5)*5 for x in base];vals[0]+=total-sum(vals);rows.append(vals)
    countries.append(dict(slug=slug,name=name,summary=c.get('summary',c.get('assessment',c.get('verdict'))),sections=sections,budgets=rows,**m))
countries.sort(key=lambda c:['greece','italy','thailand','uae','spain','portugal','mexico','panama'].index(c['slug']))
payload={'date':'2026-11-08','categories':categories,'countries':countries,'sources':sources}
(ROOT/'assets'/'data.js').write_text('window.GUIDE = '+json.dumps(payload,ensure_ascii=False,separators=(',',':'))+';\n')
print(f'Generated {len(countries)} countries and {len(sources)} source entries.')
